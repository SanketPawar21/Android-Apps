package com.example.custom_toast_alert;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Show custom toast when activity starts
        showCustomToast("Welcome to Custom Toast!", R.drawable.ic_success);
    }

    private void showCustomToast(String message, int iconResId) {
        // Inflate custom toast layout
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_main, findViewById(android.R.id.content), false);

        // Set icon and message
        ImageView toastIcon = layout.findViewById(R.id.toast_icon);
        TextView toastMessage = layout.findViewById(R.id.toast_message);

        toastIcon.setImageResource(iconResId);
        toastMessage.setText(message);

        // Create and show Toast
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }
}
