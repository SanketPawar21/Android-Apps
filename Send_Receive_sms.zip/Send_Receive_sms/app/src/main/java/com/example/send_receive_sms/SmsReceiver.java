package com.example.send_receive_sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                String format = bundle.getString("format"); // Required for new Android versions

                if (pdus != null) {
                    for (Object pdu : pdus) {
                        SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
                        String sender = smsMessage.getDisplayOriginatingAddress();
                        String messageBody = smsMessage.getMessageBody();

                        // Log received message
                        Log.d("SmsReceiver", "SMS from " + sender + ": " + messageBody);

                        // Show a Toast message
                        Toast.makeText(context, "New SMS: " + messageBody, Toast.LENGTH_LONG).show();

                        // Send received SMS data to MainActivity
                        Intent broadcastIntent = new Intent("SMS_RECEIVED_ACTION");
                        broadcastIntent.putExtra("sender", sender);
                        broadcastIntent.putExtra("message", messageBody);
                        context.sendBroadcast(broadcastIntent);
                    }
                }
            }
        }
    }
}
