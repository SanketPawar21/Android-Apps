package com.idealtech.loginauthwith_database;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        DatabaseHelper db = new DatabaseHelper(this);

        TextView txtName = findViewById(R.id.txtName);
        TextView txtMobile = findViewById(R.id.txtMobile);
        TextView txtEmail = findViewById(R.id.txtEmail);

        String email = getIntent().getStringExtra("email");

        Cursor c = db.getUserByEmail(email);
        if (c.moveToFirst()) {
            txtName.setText("Name: " + c.getString(1));
            txtMobile.setText("Mobile: " + c.getString(2));
            txtEmail.setText("Email: " + c.getString(3));
        }
        c.close();
    }
}
