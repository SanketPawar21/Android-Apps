package com.idealtech.calculator_gridview;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView txtResult;
    GridLayout gridLayout;

    String currentInput = "";
    double firstValue = 0;
    String operator = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtResult = findViewById(R.id.txtResult);
        gridLayout = findViewById(R.id.gridLayout);

        // Attach click listener to all buttons in GridLayout
        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            View view = gridLayout.getChildAt(i);
            if (view instanceof Button) {
                ((Button) view).setOnClickListener(buttonClickListener);
            }
        }
    }

    private final View.OnClickListener buttonClickListener = view -> {
        Button button = (Button) view;
        String value = button.getText().toString();

        if ("0123456789.".contains(value)) {
            currentInput += value;
            txtResult.setText(currentInput);
        }
        else if ("+-*/%".contains(value)) {
            if (!currentInput.isEmpty()) {
                firstValue = Double.parseDouble(currentInput);
                operator = value;
                currentInput = "";
            }
        }
        else if (value.equals("=")) {
            if (!currentInput.isEmpty() && !operator.isEmpty()) {
                double secondValue = Double.parseDouble(currentInput);
                double result = calculate(firstValue, secondValue, operator);
                txtResult.setText(removeDecimal(result));
                currentInput = removeDecimal(result);
                operator = "";
            }
        }
        else if (value.equals("C")) {
            clearAll();
        }
    };

    private double calculate(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/": return b != 0 ? a / b : 0;
            case "%": return a % b;
            default: return 0;
        }
    }

    private void clearAll() {
        currentInput = "";
        firstValue = 0;
        operator = "";
        txtResult.setText("0");
    }

    private String removeDecimal(double value) {
        if (value == (long) value)
            return String.valueOf((long) value);
        else
            return String.valueOf(value);
    }
}
