package com.example.progress_bar;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressCircular, progressHorizontal;
    TextView txtPercent;
    Button btnStart;

    int progressStatus = 0;
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressCircular = findViewById(R.id.progressCircular);
        progressHorizontal = findViewById(R.id.progressHorizontal);
        txtPercent = findViewById(R.id.txtPercent);
        btnStart = findViewById(R.id.btnStart);

        btnStart.setOnClickListener(v -> startProgress());
    }

    private void startProgress() {
        progressStatus = 0;
        progressCircular.setVisibility(ProgressBar.VISIBLE);
        progressHorizontal.setVisibility(ProgressBar.VISIBLE);

        new Thread(() -> {
            while (progressStatus < 100) {
                progressStatus += 1;

                handler.post(() -> {
                    progressHorizontal.setProgress(progressStatus);
                    txtPercent.setText(progressStatus + " %");
                });

                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            handler.post(() -> progressCircular.setVisibility(ProgressBar.GONE));
        }).start();
    }
}
