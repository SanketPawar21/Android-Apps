package com.idealtech.modebroadcast;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSilent = findViewById(R.id.btnSilent);
        Button btnVibrate = findViewById(R.id.btnVibrate);
        Button btnLoud = findViewById(R.id.btnLoud);

        btnSilent.setOnClickListener(v -> {
            Intent intent = new Intent("ACTION_SILENT_MODE").setClassName(/* TODO: provide the application ID. For example: */ getPackageName(), "com.idealtech.modebroadcast.ModeReceiver");
            sendBroadcast(intent);
        });

        btnVibrate.setOnClickListener(v -> {
            Intent intent = new Intent("ACTION_VIBRATE_MODE").setClassName(/* TODO: provide the application ID. For example: */ getPackageName(), "com.idealtech.modebroadcast.ModeReceiver");
            sendBroadcast(intent);
        });

        btnLoud.setOnClickListener(v -> {
            Intent intent = new Intent("ACTION_LOUD_MODE").setClassName(/* TODO: provide the application ID. For example: */ getPackageName(), "com.idealtech.modebroadcast.ModeReceiver");
            sendBroadcast(intent);
        });
    }
}
