package com.idealtech.modebroadcast;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.widget.Toast;

public class ModeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        AudioManager audioManager =
                (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Required for Android 6+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !nm.isNotificationPolicyAccessGranted()) {

            Toast.makeText(
                    context,
                    "Allow Do Not Disturb permission",
                    Toast.LENGTH_LONG
            ).show();

            Intent settingsIntent =
                    new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            settingsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(settingsIntent);
            return;
        }

        switch (intent.getAction()) {

            case "ACTION_SILENT_MODE":
                audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                Toast.makeText(context, "Silent Mode Activated", Toast.LENGTH_SHORT).show();
                break;

            case "ACTION_VIBRATE_MODE":
                audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                Toast.makeText(context, "Vibrate Mode Activated", Toast.LENGTH_SHORT).show();
                break;

            case "ACTION_LOUD_MODE":
                audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                Toast.makeText(context, "Loud Mode Activated", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
