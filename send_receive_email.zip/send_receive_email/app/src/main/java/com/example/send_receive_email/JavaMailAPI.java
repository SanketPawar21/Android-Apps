package com.example.send_receive_email;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class JavaMailAPI {
    private final String emailSender = "sanketpawar1983@gmail.com"; // Your Gmail
    private final String password = "leet pumh nkwq mrdk"; // replace with your app password// Use App Password ||  go to https://myaccount.google.com/apppasswords
    private final String recipientEmail;                  // for generate "leet pumh nkwq mrdk" this password
    private final String emailSubject;
    private final String emailMessage;

    public JavaMailAPI(String recipientEmail, String subject, String message) {
        this.recipientEmail = recipientEmail;
        this.emailSubject = subject;
        this.emailMessage = message;
    }

    public void sendEmail() {
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587"); // Use 587 with STARTTLS
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(emailSender, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(emailSubject);
            message.setText(emailMessage);

            Transport.send(message);
            System.out.println("✅ Email sent successfully to: " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("❌ Error sending email: " + e.getMessage());
        }
    }
}



//leet pumh nkwq mrdk