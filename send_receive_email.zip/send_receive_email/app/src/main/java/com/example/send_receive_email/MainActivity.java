package com.example.send_receive_email;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private EditText emailInput, subjectInput, messageInput;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailInput = findViewById(R.id.emailInput);
        subjectInput = findViewById(R.id.subjectInput);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipient = emailInput.getText().toString().trim();
                String subject = subjectInput.getText().toString().trim();
                String message = messageInput.getText().toString().trim();

                if (recipient.isEmpty() || subject.isEmpty() || message.isEmpty()) {
                    Toast.makeText(MainActivity.this, "All fields are required!", Toast.LENGTH_LONG).show();
                } else {
                    sendEmailInBackground(recipient, subject, message);
                }
            }
        });
    }

    private void sendEmailInBackground(String recipient, String subject, String message) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                JavaMailAPI javaMailAPI = new JavaMailAPI(recipient, subject, message);
                javaMailAPI.sendEmail();

                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "✅ Email Sent Successfully", Toast.LENGTH_LONG).show()
                );
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "❌ Failed to send email", Toast.LENGTH_LONG).show()
                );
            }
        });
    }
}
